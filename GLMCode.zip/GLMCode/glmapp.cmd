@echo off
start "" pythonw -m glmcode.gui
